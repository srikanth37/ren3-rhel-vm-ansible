#!/bin/bash

set -e

# Constants
REPO_URL="https://github.com/srikanth37/ren3-rhel-vm-ansible.git"
CLONE_DIR="ren3-rhel-vm-ansible"
CONFIG_FILE="config.json"

# Prerequisites: Ensure Python3 and Ansible are installed
echo "Checking prerequisites..."

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "Python3 not found. Installing..."
    sudo yum install -y python3
else
    echo "Python3 is already installed."
fi

# Check Pip
if ! command -v pip3 &> /dev/null; then
    echo "pip3 not found. Installing..."
    sudo yum install -y python3-pip
else
    echo "pip3 is already installed."
fi

# Check Ansible
if ! command -v ansible &> /dev/null; then
    echo "Ansible not found. Installing..."
    sudo pip3 install ansible
else
    echo "Ansible is already installed."
fi

# Check Git
if ! command -v git &> /dev/null; then
    echo "Git not found. Installing..."
    sudo yum install -y git
else
    echo "Git is already installed."
fi

# Check jq
if ! command -v jq &> /dev/null; then
    echo "jq not found. Installing..."
    sudo yum install -y jq || sudo dnf install -y jq
else
    echo "jq is already installed."
fi

# Clone the Ansible repo
if [ -d "$CLONE_DIR" ]; then
    echo "Directory $CLONE_DIR already exists. Removing..."
    rm -rf "$CLONE_DIR"
fi

echo "Cloning Ansible repo..."
git clone "$REPO_URL" "$CLONE_DIR"

# Copy the SSL files to the Ansible repo
echo "Copying SSL files to the Ansible repo..."
cp ren3ssl.crt "$CLONE_DIR"/roles/nginx/templates/
cp ren3ssl.key "$CLONE_DIR"/roles/nginx/templates/

cd "$CLONE_DIR"

# Parse values from config.json and inject into group_vars
echo "Updating group_vars with values from $CONFIG_FILE..."

update_var() {
    local key=$1
    local value=$(jq -r ".$key" "../$CONFIG_FILE")
    safe_value=$(printf '%s\n' "$value" | sed 's/[\/&]/\\&/g')
    sed -i.bak "s/${key}_placeholder/$safe_value/g" inventories/production/group_vars/all.yml
}

update_var "app_user"
update_var "app_group"
update_var "app_home"
update_var "app_server_url"
update_var "dotnet_version"
update_var "dotnet_dir"
update_var "node_version"
update_var "qdrant_storage_dir"
update_var "qdrant_host"
update_var "react_app_backend_url"
update_var "react_app_portal_url"
update_var "ingestor_url"
update_var "server_url"
update_var "ej2apiservices_url"
update_var "frontend_server_name"
update_var "backend_server_name"
update_var "grafana_server_name"
update_var "mariadb_root_password"
update_var "db_hostname"
update_var "license_key"
update_var "squadcast_url"


# Handle array: mariadb_databases
echo "Updating mariadb_databases array..."
database_name=$(jq -r '.mariadb_databases[0].name' ../$CONFIG_FILE)
sed -i.bak "s/mariadb_database_name_placeholder/${database_name}/g" inventories/production/group_vars/all.yml


# Run Ansible playbook
echo "Running Ansible playbook..."
ansible-playbook -i inventory.ini playbooks/site.yml
